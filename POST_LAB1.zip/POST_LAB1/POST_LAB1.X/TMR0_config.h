
/* UNIVERSIDAD DEL VALLE DE GUATEMALA
 * DEPARTAMENTO DE INGENIERIA ELCTRONICA & MECATRONICA
 * CURSO: ELECTRONICA DIGITAL 2
 * LABORATORIO No.1
 * 
 * File:   TMR0_config.h
 * Author: BRAYAN GABRIEL GIRON GARCIA
 *
 * Created on January 23, 2023
 */


#ifndef TMR0_CONFIG_H
#define	TMR0_CONFIG_H

//______________________________________________________________________________
// DECLARACION DE VARIABLES
//______________________________________________________________________________

#ifndef _tmr0_value
#define _tmr0_value  236    // Valor a cargar
#endif

//------------------------------------------------------------------------------------------------------------------------------------------------
// LIBRERIAS
//------------------------------------------------------------------------------------------------------------------------------------------------

#include <stdint.h>
#include <xc.h>
#include "TMR0_config.h"

//******************************************************************************
// Prototipo de la funcion para configurar el TIMER0
// Parametros: Prescaler y reload
// Revisar pagina 73 del manual del pic
//******************************************************************************

//______________________________________________________________________________
// PROTOTIPOS DE FUNCIONES
//______________________________________________________________________________

void tmr0_init (uint8_t prescaler);
uint8_t tmr0_reload_v2 (void);



#endif	/* TMR0_CONFIG_H */

//______________________________________________________________________________
//______________________________________________________________________________


