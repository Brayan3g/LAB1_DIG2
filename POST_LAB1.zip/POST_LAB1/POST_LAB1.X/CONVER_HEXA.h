/* UNIVERSIDAD DEL VALLE DE GUATEMALA
 * DEPARTAMENTO DE INGENIERIA ELCTRONICA & MECATRONICA
 * CURSO: ELECTRONICA DIGITAL 2
 * LABORATORIO No.1
 * 
 * File:   oscilador_config.h
 * Author: BRAYAN GABRIEL GIRON GARCIA
 *
 * Created on January 24, 2023
 */


#ifndef CONVER_HEXA_H
#define	CONVER_HEXA_H


//------------------------------------------------------------------------------------------------------------------------------------------------
// LIBRERIAS
//------------------------------------------------------------------------------------------------------------------------------------------------

#include <stdint.h>
#include <xc.h>
#include "CONVER_HEXA.h"

//______________________________________________________________________________
// DECLARACION DE VARIABLES
//______________________________________________________________________________

uint8_t UNID;
uint8_t DECE;
uint8_t CENT;
uint8_t NUM_1;
uint8_t NUM_2;
uint8_t NUM_3;
uint8_t V;
//******************************************************************************
// Prototipo de la funcion para convertir el valor adc en hexadecimal para 
// Display de 7 seg.
//******************************************************************************

//______________________________________________________________________________
// PROTOTIPOS DE FUNCIONES
//______________________________________________________________________________

int  TABLA(int V1);            // Funcion de conversion 7 seg.
void DECIMAL(void);            // Funcion de conversion a Decimal.
void HEXADECIMAL(void);        // Funcion de conversion a Hexadecimal.

#endif	/* CONVER_HEXA_H */

//______________________________________________________________________________
//______________________________________________________________________________



