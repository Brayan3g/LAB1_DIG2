
/* UNIVERSIDAD DEL VALLE DE GUATEMALA
 * DEPARTAMENTO DE INGENIERIA ELCTRONICA & MECATRONICA
 * CURSO: ELECTRONICA DIGITAL 2
 * LABORATORIO No.1
 * 
 * File:   Main_POSTLAB1.c
 * Author: BRAYAN GABRIEL GIRON GARCIA
 *
 * Created on January 23, 2023, 2:58 AM
 */
//-----------------------------------------------------------------------------------------------------------------------------------------------
// CONFIG1
//-----------------------------------------------------------------------------------------------------------------------------------------------
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is enabled)
#pragma config LVP = ON         // Low Voltage Programming Enable bit (RB3/PGM pin has PGM function, low voltage programming enabled)

//-----------------------------------------------------------------------------------------------------------------------------------------------
// CONFIG2
//-----------------------------------------------------------------------------------------------------------------------------------------------
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//-----------------------------------------------------------------------------------------------------------------------------------------------
// LIBRERIAS
//-----------------------------------------------------------------------------------------------------------------------------------------------
#include <xc.h>
#include <stdint.h>             // AGREGAMOS LIBRERIRAS DE TIPOS DE DATOS ESTANDAR Y OTROS.
#include "ADC_LIB.h"            // AGREGAMOS LA LIBRERIRA DEL ADC.
#include "TMR0_config.h"        // Libreria para configurar TMR0
#include "oscilador_config.h"   // Libreria para seleccionar Oscilador
#include "CONVER_HEXA.h"


//-----------------------------------------------------------------------------------------------------------------------------------------------
// DIRECTIVAS DEL COPILADOR
//-----------------------------------------------------------------------------------------------------------------------------------------------
#define _XTAL_FREQ 4000000      /* ESPECIFICAMOS LA FRECUENCIA DE RELOJ,
                                   PARA PODER USAR LOS DELAY EN EL PROGRAMA.*/
//______________________________________________________________________________
// DECLARACION DE VARIABLES
//______________________________________________________________________________

uint8_t V;
uint8_t V1;
uint8_t UNID;
uint8_t DECE;
uint8_t CENT;
uint8_t NUM_1;
uint8_t NUM_2;
uint8_t NUM_3;
uint8_t SELEC;

uint8_t ALARMA;

//______________________________________________________________________________
// PROTOTIPOS DE FUNCIONES
//______________________________________________________________________________

void SETUP(void);              // Funcion de configuraciones. 
void DECIMAL(void);            // Funcion de conversion a Decimal.
void HEXADECIMAL(void);        // Funcion de conversion a Hexadecimal.

//______________________________________________________________________________
// FUNCION DE INTERRUPCIONES
//______________________________________________________________________________

void __interrupt() isr(void){

//----------------------------- INTERRUPCION TMR0 ------------------------------    
    if(T0IF == 1) {
        
        tmr0_reload_v2();
        PORTB = 0;
        
        if(V >= ALARMA){
            PORTE = 0b111;}
        else{
            PORTE = 0;
        }

        if(SELEC == 0){
            V1    = NUM_1;
            PORTC = TABLA(V1);
            RB3   = 1;
            SELEC = 1;
            return;
        }    
        if(SELEC == 1){
            V1    = NUM_2;
            PORTC = TABLA(V1);
            RB4   = 1;
            SELEC = 2;
            return;
        }    
        if(SELEC == 2){
            V1    = NUM_3;
            PORTC = TABLA(V1);
            RB5   = 1;
            SELEC = 0;
            return;
        }
    }
    
//----------------------------- INTERRUPCION ADC -------------------------------     
    
  if(ADIF == 1){               // Revisamos si la bandera del ADC esta levantada.   
      if(ADCON0bits.CHS == 0){ // Revisamos si esta en el canal 0. 
         PORTD = adc_read();}  // Asignamos el valor convertido al PORTD.   
      else{                   
          V = adc_read();}
  }  
}    
    
//______________________________________________________________________________
// FUNCION PRINCIPAL (MAIN & LOOP)
//______________________________________________________________________________

void main(void){
     SETUP();                 // Llamamos a la funcion de configuracion.    
     while(1){
                    
         HEXADECIMAL();       // Llamamos a la funciond de conversion a decimal.
                 
         if(ADCON0bits.GO == 0){      // Revisamos si ya termino la converion.
             if(ADCON0bits.CHS == 0){ // Revisamos si esta en el canal 0.
                 ADCON0bits.CHS = 1;} // Cambiamos al canal 1. 
             else{ 
                 ADCON0bits.CHS = 0;} // Cambiamos al canal 0. 
             __delay_us(50);
             ADCON0bits .GO = 1;      // Encendemos la conversion nuevamente.     
         }
     }     
}

//______________________________________________________________________________
// FUNCION DE CONVERSION HEXADECIMAL PARA DISPLAY 7-SEG.
//______________________________________________________________________________

void HEXADECIMAL(void){  // Convertimos el valor de V a Hexadecimal.
     NUM_3 = 0;  
     NUM_2 = V/16;
     NUM_1 = (V - NUM_2*16);  
} 

//______________________________________________________________________________
// FUNCION DE CONFIGURACION
//______________________________________________________________________________

void SETUP(void){
 
//------------------- CONFIGURACION DE ENTRADAS Y SALIDAS ----------------------
    ANSEL  = 0b00000011;    // Seleccionamos las entradas AN1 & AN2.   
    ANSELH = 0x00;          // Desactivamos las otras entradas analogicas. 
 
    TRISB = 0x00;           // Declaramos el PORTB como salidas.
    TRISC = 0x00;           // Declaramos el PORTC como salidas.
    TRISA = 0x3;            // Declaramos el pin 0 y 1 del PORTA como entradas. 
    TRISD = 0x00;           // Declaramos el PORTD com salidas.
    TRISE = 0x00;           // Declaramos el PORTE como salidas.
    
    PORTB = 0x00;           // Limpiamos los puertos.
    PORTC = 0x00;
    PORTA = 0x00;
    PORTD = 0x00;  
    PORTE = 0x00;
//---------------------- CONFIGURACION DE RELOJ A 4MHZ -------------------------
    int_osc_MHz(2);          // 4 MHz 
    
//-------------------------- CONFIGURACION DE ADC ------------------------------
    adc_init(1,0,0);         // (Fosc/8), VDD, VSS. 
    adc_start(0);            // CHANEL 0, Encendemos ADC, Iniciamos conversion.

//-------------------------- CONFIGURACION DEL TMR0 ----------------------------
    tmr0_init(7);               // 1:256

//---------------------- CONFIGURACION DE INTERRUPCIONES -----------------------
    INTCONbits.GIE  = 1;     // Habilitamos las interrupciones globales.
    INTCONbits.PEIE = 1;     // Habilitamos las interrupciones perifericas.
    PIR1bits.ADIF   = 0;     // Limpiamos la bandera del ADC.

//---------------------- CONFIGURACION DE ALARMA LED ---------------------------
    ALARMA =10;   /* Selecionamos un valor entre 0 y 255 en el cual queeremos
                    que se encianeda el led de alarma*/
} 

//______________________________________________________________________________
//______________________________________________________________________________
